# Team Prompt Skills 1.0.0

7 detailed, local-first image/video prompt-authoring skills for Codex and Claude.

- Start with [USAGE_KO.md](USAGE_KO.md) for installation, natural-language requests and examples.
- Codex: install each skills/<name> folder under .agents/skills; invoke $<name>.
- Claude Code: install each skills/<name> folder under .claude/skills; invoke /<name>.
- Claude web/Desktop/Cowork: upload individual archives from claude-upload and enable them in Skills.
- Optional installer: Python 3.8+, standard library only. Run `python install.py --help` or `python install.py --verify`.
- Optional team execution instructions: [PROJECT_INSTRUCTIONS.md](PROJECT_INSTRUCTIONS.md).

Prompt writing needs no ComfyUI/model installation. Actual generation requires a compatible connected execution environment. Models, source images, user workflows, credentials and MCP server software are not bundled. Existing local skill files were copied into this distribution; portability adjustments affect this package only.

Manual sources were checked 2026-11-03. Each skill contains its own source/coverage record. Numerical API or node snapshots are dated and route-specific. No network download is performed by the installer.
